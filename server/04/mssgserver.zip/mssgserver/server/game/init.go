package game

import (
	"mssgserver/db"
	"mssgserver/net"
	"mssgserver/server/game/controller"
	"mssgserver/server/game/gameConfig"
)

var Router = &net.Router{}
func Init()  {
	db.TestDB()
	//加载基础配置
	gameConfig.Base.Load()
	//加载地图的资源配置
	gameConfig.MapBuildConf.Load()
	initRouter()
}

func initRouter() {
	controller.DefaultRoleController.Router(Router)
	controller.DefaultNationMapController.Router(Router)
}
