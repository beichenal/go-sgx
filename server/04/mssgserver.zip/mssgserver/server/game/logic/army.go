package logic

import (
	"log"
	"mssgserver/constant"
	"mssgserver/db"
	"mssgserver/server/common"
	"mssgserver/server/game/model"
	"mssgserver/server/game/model/data"
)

var ArmyService = &armyService{}
type armyService struct {

}

func (r *armyService) GetArmys(rid int) ([]model.Army,error)  {
	mrs := make([]data.Army,0)
	mr := &data.Army{}
	err := db.Engine.Table(mr).Where("rid=?",rid).Find(&mrs)
	if err != nil {
		log.Println("军队查询出错",err)
		return nil, common.New(constant.DBError,"军队查询出错")
	}
	modelMrs := make([]model.Army,len(mrs))
	for _,v := range mrs{
		modelMrs = append(modelMrs,v.ToModel().(model.Army))
	}
	return modelMrs,nil
}
