package logic

import (
	"log"
	"mssgserver/constant"
	"mssgserver/db"
	"mssgserver/server/common"
	"mssgserver/server/game/model"
	"mssgserver/server/game/model/data"
)

var RoleBuildService = &roleBuildService{}
type roleBuildService struct {

}

func (r *roleBuildService) GetBuilds(rid int) ([]model.MapRoleBuild,error)  {
	mrs := make([]data.MapRoleBuild,0)
	mr := &data.MapRoleBuild{}
	err := db.Engine.Table(mr).Where("rid=?",rid).Find(&mrs)
	if err != nil {
		log.Println("建筑查询出错",err)
		return nil, common.New(constant.DBError,"建筑查询出错")
	}
	modelMrs := make([]model.MapRoleBuild,len(mrs))
	for _,v := range mrs{
		modelMrs = append(modelMrs,v.ToModel().(model.MapRoleBuild))
	}
	return modelMrs,nil
}
