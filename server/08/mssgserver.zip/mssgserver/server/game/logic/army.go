package logic

import (
	"log"
	"mssgserver/constant"
	"mssgserver/db"
	"mssgserver/server/common"
	"mssgserver/server/game/global"
	"mssgserver/server/game/model"
	"mssgserver/server/game/model/data"
	"mssgserver/utils"
	"sync"
)

var ArmyService = &armyService{
	passByPosArmys: make(map[int]map[int]*data.Army),
}
type armyService struct {
	passBy  		sync.RWMutex
	passByPosArmys 	map[int]map[int]*data.Army //玩家路过位置的军队 key:posId,armyId
}

func (r *armyService) GetArmys(rid int) ([]model.Army,error)  {
	mrs := make([]data.Army,0)
	mr := &data.Army{}
	err := db.Engine.Table(mr).Where("rid=?",rid).Find(&mrs)
	if err != nil {
		log.Println("军队查询出错",err)
		return nil, common.New(constant.DBError,"军队查询出错")
	}
	modelMrs := make([]model.Army,0)
	for _,v := range mrs{
		modelMrs = append(modelMrs,v.ToModel().(model.Army))
	}
	return modelMrs,nil
}

func (r *armyService) GetArmysByCity(rid ,cId int) ([]model.Army,error)  {
	mrs := make([]data.Army,0)
	mr := &data.Army{}
	err := db.Engine.Table(mr).Where("rid=? and cityId=?",rid,cId).Find(&mrs)
	if err != nil {
		log.Println("军队查询出错",err)
		return nil, common.New(constant.DBError,"军队查询出错")
	}
	modelMrs := make([]model.Army,0)
	for _,v := range mrs{
		modelMrs = append(modelMrs,v.ToModel().(model.Army))
	}
	return modelMrs,nil
}

func (a *armyService) ScanBlock(roleId int,req *model.ScanBlockReq) ([]model.Army, error) {
	x := req.X
	y := req.Y
	length := req.Length
	out := make([]model.Army, 0)
	if x < 0 || x >= global.MapWith || y < 0 || y >= global.MapHeight {
		return out,nil
	}

	maxX := utils.MinInt(global.MapWith, x+length-1)
	maxY := utils.MinInt(global.MapHeight, y+length-1)

	a.passBy.RLock()
	defer a.passBy.RUnlock()
	for i := x; i <= maxX; i++ {
		for j := y; j <= maxY; j++ {
			posId := global.ToPosition(i, j)
			armys, ok := a.passByPosArmys[posId]
			if ok {
				//是否在视野范围内
				is := armyIsInView(roleId, i, j)
				if is == false{
					continue
				}
				for _, army := range armys {
					out = append(out, army.ToModel().(model.Army))
				}
			}
		}
	}
	return out,nil
}

func (a *armyService) updateGenerals(armys... *data.Army) {
	for _, army := range armys {
		army.Gens = make([]*data.General, 0)
		for _, gid := range army.GeneralArray {
			if gid == 0{
				army.Gens = append(army.Gens, nil)
			}else{
				g, _ := GeneralService.Get(gid)
				army.Gens = append(army.Gens, g)
			}
		}
	}
}


func (r *armyService) GetArmyByCityAndOrder(rid ,cId int,order int8) (*data.Army,bool)  {
	armys := make([]*data.Army,0)
	mr := &data.Army{}
	err := db.Engine.Table(mr).Where("rid=? and cityId=?",rid,cId).Find(&armys)
	if err != nil {
		log.Println("军队查询出错",err)
		return nil, false
	}
	for _,army :=range armys {
		if army.Order == order {
			r.updateGenerals(army)
			return army,true
		}
	}
	return nil, false
}

func (a *armyService) GetCreate(cid int, rid int, order int8) (*data.Army, bool) {
	//根据城池id 角色id，order 进行查询
	//有 返回 没有创建并返回
	army,ok := a.GetArmyByCityAndOrder(rid,cid,order)
	if ok {
		return army,true
	}
	//需要创建
	army = &data.Army{
		RId: rid,
		Order: order,
		CityId: cid,
		Generals: `[0,0,0]`,
		Soldiers: `[0,0,0]`,
		GeneralArray: []int{0,0,0},
		SoldierArray: []int{0,0,0},
		ConscriptCnts: `[0,0,0]`,
		ConscriptTimes: `[0,0,0]`,
		ConscriptCntArray: []int{0,0,0},
		ConscriptTimeArray: []int64{0,0,0},
	}
	a.updateGenerals(army)
	_,err := db.Engine.Table(army).Insert(army)
	if err != nil {
		log.Println("armyService GetCreate err",err)
		return nil,false
	}
	return army,true
}


func (r *armyService) GetDbArmys(rid int) ([]*data.Army,error)  {
	mrs := make([]*data.Army,0)
	mr := &data.Army{}
	err := db.Engine.Table(mr).Where("rid=?",rid).Find(&mrs)
	if err != nil {
		log.Println("军队查询出错",err)
		return nil, common.New(constant.DBError,"军队查询出错")
	}
	return mrs,nil
}

func (r *armyService) IsRepeat(rid int, cfgId int) bool {
	armys,err := r.GetDbArmys(rid)
	if err != nil {
		return true
	}
	for _ ,v := range armys{
		for _,gId := range v.GeneralArray{
			if gId == cfgId {
				return true
			}
		}
	}
	return false
}

func armyIsInView(rid, x, y int) bool {
	//简单点 先设为true
	return true
}
