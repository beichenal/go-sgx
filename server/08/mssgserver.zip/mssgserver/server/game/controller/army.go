package controller

import (
	"github.com/mitchellh/mapstructure"
	"mssgserver/constant"
	"mssgserver/net"
	"mssgserver/server/common"
	"mssgserver/server/game/gameConfig"
	"mssgserver/server/game/gameConfig/general"
	"mssgserver/server/game/logic"
	"mssgserver/server/game/middleware"
	"mssgserver/server/game/model"
	"mssgserver/server/game/model/data"
)

var DefaultArmyController = &ArmyController{}
type ArmyController struct {

}

func (a *ArmyController) Router(router *net.Router)  {
	g := router.Group("army")
	g.Use(middleware.Log())
	g.AddRouter("myList",a.myList,middleware.CheckRole())
	g.AddRouter("dispose",a.dispose,middleware.CheckRole())
}

func (a *ArmyController) myList(req *net.WsMsgReq, rsp *net.WsMsgRsp) {
	reqObj := &model.ArmyListReq{}
	rspObj := &model.ArmyListRsp{}
	mapstructure.Decode(req.Body.Msg,reqObj)
	rsp.Body.Seq = req.Body.Seq
	rsp.Body.Name = req.Body.Name
	role, err := req.Conn.GetProperty("role")
	if err != nil {
		rsp.Body.Code = constant.SessionInvalid
		return
	}
	rid := role.(*data.Role).RId

	armys , err := logic.ArmyService.GetArmysByCity(rid,reqObj.CityId)
	if err != nil {
		rsp.Body.Code = err.(*common.MyError).Code()
		return
	}
	rspObj.Armys = armys
	rspObj.CityId = reqObj.CityId
	rsp.Body.Code = constant.OK
	rsp.Body.Msg = rspObj
}

func (a *ArmyController) dispose(req *net.WsMsgReq, rsp *net.WsMsgRsp) {
	//判断参数是否符合要求
	reqObj := &model.DisposeReq{}
	rspObj := &model.DisposeRsp{}
	mapstructure.Decode(req.Body.Msg, reqObj)
	rsp.Body.Msg = rspObj
	rsp.Body.Code = constant.OK

	r, _ := req.Conn.GetProperty("role")
	role := r.(*data.Role)
	if reqObj.Order < 0 || reqObj.Position < -1 || reqObj.Position > 2 || reqObj.Order > 5 {
		rsp.Body.Code = constant.InvalidParam
		return
	}
	rc , ok := logic.RoleCityService.Get(reqObj.CityId)
	if !ok {
		rsp.Body.Code = constant.CityNotExist
		return
	}
	if role.RId != rc.RId {
		rsp.Body.Code = constant.CityNotMe
		return
	}
	//判断校场的等级 3 只能配置3个队伍
	level := logic.CityFacilityService.GetFacilityLevel(reqObj.CityId,gameConfig.JiaoChang)
	if level <= 0 || reqObj.Order > level {
		rsp.Body.Code = constant.ArmyNotEnough
		return
	}
	//武将是否存在
	newGen,ok := logic.GeneralService.Get(reqObj.GeneralId)
	if !ok  {
		rsp.Body.Code = constant.GeneralNotFound
		return
	}
	//武将是否是当前角色的
	if newGen.RId != role.RId {
		rsp.Body.Code = constant.GeneralNotMe
		return
	}
	//查询当前位置的军队 没有就创建
	army,ok := logic.ArmyService.GetCreate(reqObj.CityId,role.RId,reqObj.Order)
	//需要判断军队是否是在城外 如果在城外不能进行上下阵
	if (army.FromX > 0 && army.FromX != rc.X )|| (army.FromY > 0 && army.FromY != rc.Y) {
		rsp.Body.Code = constant.ArmyIsOutside
		return
	}
	//上下阵处理
	if reqObj.Position == -1 {
		//下阵
		for position,g := range army.Gens{
			if g != nil && g.Id == reqObj.GeneralId {
				//检测武将是否在征兵中
				if !army.PositionCanModify(position) {
					rsp.Body.Code = constant.GeneralBusy
					return
				}
				army.GeneralArray[position] = 0
				army.SoldierArray[position] = 0
				army.Gens[position] = nil
				army.SyncExecute()
			}

		}
		newGen.CityId = 0
		newGen.Order = 0
		newGen.SyncExecute()
	}else{
		//上阵
		//检测武将是否在征兵中
		if !army.PositionCanModify(reqObj.Position) {
			rsp.Body.Code = constant.GeneralBusy
			return
		}
		//武将已经上阵过了
		if newGen.CityId != 0{
			rsp.Body.Code = constant.GeneralBusy
			return
		}
		if logic.ArmyService.IsRepeat(role.RId, newGen.CfgId){
			rsp.Body.Code = constant.GeneralRepeat
			return
		}
		level := logic.CityFacilityService.GetFacilityLevel(rc.CityId, gameConfig.TongShuaiTing)
		if reqObj.Position == 2 && (  level < reqObj.Order) {
			rsp.Body.Code = constant.TongShuaiNotEnough
			return
		}
		//判断cost
		cost := general.General.Cost(newGen.CfgId)
		for _,g := range army.Gens {
			if g != nil {
				cost += general.General.Cost(g.CfgId)
			}
		}
		cityCost := logic.RoleCityService.GetCityCost(reqObj.CityId)
		if cityCost < cost {
			rsp.Body.Code = constant.CostNotEnough
			return
		}
		oldG := army.Gens[reqObj.Position]
		if oldG != nil {
			//旧的下阵
			oldG.CityId = 0
			oldG.Order = 0
			oldG.SyncExecute()
		}
		army.GeneralArray[reqObj.Position] = reqObj.GeneralId
		army.SoldierArray[reqObj.Position] = 0
		army.Gens[reqObj.Position] = newGen
		newGen.Order = reqObj.Order
		newGen.CityId = reqObj.CityId
		newGen.SyncExecute()
	}
	army.FromX = rc.X
	army.FromY = rc.Y
	army.SyncExecute()
	//队伍
	rspObj.Army = army.ToModel().(model.Army)
}
