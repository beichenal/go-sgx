package controller

import (
	"github.com/mitchellh/mapstructure"
	"mssgserver/constant"
	"mssgserver/net"
	"mssgserver/server/common"
	"mssgserver/server/game/logic"
	"mssgserver/server/game/model"
	"mssgserver/server/game/model/data"
)

var DefaultArmyController = &ArmyController{}
type ArmyController struct {

}

func (a *ArmyController) Router(router *net.Router)  {
	g := router.Group("army")
	g.AddRouter("myList",a.myList)
}

func (a *ArmyController) myList(req *net.WsMsgReq, rsp *net.WsMsgRsp) {
	reqObj := &model.ArmyListReq{}
	rspObj := &model.ArmyListRsp{}
	mapstructure.Decode(req.Body.Msg,reqObj)
	rsp.Body.Seq = req.Body.Seq
	rsp.Body.Name = req.Body.Name
	role, err := req.Conn.GetProperty("role")
	if err != nil {
		rsp.Body.Code = constant.SessionInvalid
		return
	}
	rid := role.(*data.Role).RId

	armys , err := logic.ArmyService.GetArmysByCity(rid,reqObj.CityId)
	if err != nil {
		rsp.Body.Code = err.(*common.MyError).Code()
		return
	}
	rspObj.Armys = armys
	rspObj.CityId = reqObj.CityId
	rsp.Body.Code = constant.OK
	rsp.Body.Msg = rspObj
}
