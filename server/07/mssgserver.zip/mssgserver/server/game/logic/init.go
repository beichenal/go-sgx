package logic

import "mssgserver/server/game/model/data"

func BeforeInit()  {
	data.GetYield = RoleResService.GetYield
	data.GetUnion = RoleAttrService.GetUnion
}
